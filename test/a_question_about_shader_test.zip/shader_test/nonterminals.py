from app.symbol_type import SymbolType
from app.syntax_nonterminal import Nonterminal
from app.formatter import I, AAI, IAA, SSI, ISS, GB, GA, RestoreComment
import unittest


class NonterminalType(SymbolType):

    prog = 'prog'
    shader_body = 'shader_body'
    props = 'props'
    props_body = 'props_body'
    prop_stm = 'prop_stm'
    prop_type = 'prop_type'
    prop_init = 'prop_init'
    subshr = 'subshr'
    subshr_body = 'subshr_body'
    tags = 'tags'
    tags_body = 'tags_body'
    tag_smt = 'tag_smt'
    cmds = 'cmds'
    cmd_stm = 'cmd_stm'
    cmd_name = 'cmd_name'
    ids = 'ids'
    passes = 'passes'
    shr_pass = 'shr_pass'
    pass_body = 'pass_body'


class prog(Nonterminal):
    pass


class shader_body(Nonterminal):
    pass


class props(Nonterminal):
    pass


class props_body(Nonterminal):
    pass


class prop_stm(Nonterminal):
    pass


class prop_type(Nonterminal):
    pass


class prop_init(Nonterminal):
    pass


class subshr(Nonterminal):
    pass


class subshr_body(Nonterminal):
    pass


class tags(Nonterminal):
    pass


class tags_body(Nonterminal):
    pass


class tag_smt(Nonterminal):
    pass


class cmds(Nonterminal):
    pass


class cmd_stm(Nonterminal):
    pass


class cmd_name(Nonterminal):
    pass


class ids(Nonterminal):
    pass


class passes(Nonterminal):
    pass


class shr_pass(Nonterminal):
    pass


class pass_body(Nonterminal):
    pass


class progp1(prog):
    # prog --> 'Shader' String { shader_body }
    def __init__(self, Shader, String, LBrace, shader_body, RBrace):
        self.String = String
        self.shader_body = shader_body

    def toCode(self):
        return 'Shader' + self.String.toCode() + '{' + self.shader_body.toCode() + '}'


class shader_bodyp2(shader_body):
    # shader_body --> props subshr
    def __init__(self, props, subshr):
        self.props = props
        self.subshr = subshr

    def toCode(self):
        return self.props.toCode() + self.subshr.toCode()


class propsp3(props):
    # props --> 'Properties' { props_body }
    def __init__(self, Properties, LBrace, props_body, RBrace):
        self.props_body = props_body

    def toCode(self):
        return 'Properties' + '{' + self.props_body.toCode() + '}'


class propsp4(props):
    # props -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class props_bodyp5(props_body):
    # props_body --> prop_stm props_body
    def __init__(self, prop_stm, props_body):
        self.prop_stm = prop_stm
        self.props_body = props_body

    def toCode(self):
        return self.prop_stm.toCode() + self.props_body.toCode()


class props_bodyp6(props_body):
    # props_body -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class prop_stmp7(prop_stm):
    # prop_stm --> ID ( String , prop_type ) = prop_init
    def __init__(self, ID, LParen, String, Comma, prop_type, RParen, Assign, prop_init):
        self.ID = ID
        self.String = String
        self.prop_type = prop_type
        self.prop_init = prop_init

    def toCode(self):
        return self.ID.toCode() + '(' + self.String.toCode() + ',' + self.prop_type.toCode() + ')' + '=' + self.prop_init.toCode()


class prop_typep8(prop_type):
    # prop_type --> 'Color'
    def __init__(self, Color):
        pass

    def toCode(self):
        return 'Color'


class prop_typep9(prop_type):
    # prop_type --> 'Vector'
    def __init__(self, Vector):
        pass

    def toCode(self):
        return 'Vector'


class prop_typep10(prop_type):
    # prop_type --> 'Range'
    def __init__(self, Range):
        pass

    def toCode(self):
        return 'Range'


class prop_typep11(prop_type):
    # prop_type --> 'Int'
    def __init__(self, Int):
        pass

    def toCode(self):
        return 'Int'


class prop_typep12(prop_type):
    # prop_type --> 'Float'
    def __init__(self, Float):
        pass

    def toCode(self):
        return 'Float'


class prop_typep13(prop_type):
    # prop_type --> '2D'
    def __init__(self, _2D):
        pass

    def toCode(self):
        return '2D'


class prop_typep14(prop_type):
    # prop_type --> 'Cube'
    def __init__(self, Cube):
        pass

    def toCode(self):
        return 'Cube'


class prop_typep15(prop_type):
    # prop_type --> '3D'
    def __init__(self, _3D):
        pass

    def toCode(self):
        return '3D'


class prop_initp16(prop_init):
    # prop_init --> Number
    def __init__(self, Number):
        self.Number = Number

    def toCode(self):
        return self.Number.toCode()


class prop_initp17(prop_init):
    # prop_init --> String { }
    def __init__(self, String, LBrace, RBrace):
        self.String = String

    def toCode(self):
        return self.String.toCode() + '{' + '}'


class prop_initp18(prop_init):
    # prop_init --> ( Number , Number , Number , Number )
    def __init__(self, LParen, Number1, Comma1, Number2, Comma2, Number3, Comma3, Number4, RParen):
        self.Number1 = Number1
        self.Number2 = Number2
        self.Number3 = Number3
        self.Number4 = Number4

    def toCode(self):
        return '(' + self.Number1.toCode() + ',' + self.Number2.toCode() + ',' + self.Number3.toCode() + ',' + self.Number4.toCode() + ')'


class subshrp19(subshr):
    # subshr --> 'SubShader' { subshr_body }
    def __init__(self, SubShader, LBrace, subshr_body, RBrace):
        self.subshr_body = subshr_body

    def toCode(self):
        return 'SubShader' + '{' + self.subshr_body.toCode() + '}'


class subshr_bodyp20(subshr_body):
    # subshr_body --> tags cmds passes
    def __init__(self, tags, cmds, passes):
        self.tags = tags
        self.cmds = cmds
        self.passes = passes

    def toCode(self):
        return self.tags.toCode() + self.cmds.toCode() + self.passes.toCode()


class tagsp21(tags):
    # tags --> 'Tags' { tags_body }
    def __init__(self, Tags, LBrace, tags_body, RBrace):
        self.tags_body = tags_body

    def toCode(self):
        return 'Tags' + '{' + self.tags_body.toCode() + '}'


class tags_bodyp22(tags_body):
    # tags_body --> tag_smt tags_body
    def __init__(self, tag_smt, tags_body):
        self.tag_smt = tag_smt
        self.tags_body = tags_body

    def toCode(self):
        return self.tag_smt.toCode() + self.tags_body.toCode()


class tags_bodyp23(tags_body):
    # tags_body -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class tag_smtp24(tag_smt):
    # tag_smt --> String = String
    def __init__(self, key, Assign, value):
        self.key = key
        self.value = value

    def toCode(self):
        return self.key.toCode() + '=' + self.value.toCode()


class cmdsp25(cmds):
    # cmds --> cmd_stm cmds
    def __init__(self, cmd_stm, cmds):
        self.cmd_stm = cmd_stm
        self.cmds = cmds

    def toCode(self):
        return self.cmd_stm.toCode() + self.cmds.toCode()


class cmdsp26(cmds):
    # cmds -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class cmd_stmp27(cmd_stm):
    # cmd_stm --> cmd_name ids
    def __init__(self, cmd_name, ids):
        self.cmd_name = cmd_name
        self.ids = ids

    def toCode(self):
        return self.cmd_name.toCode() + self.ids.toCode()


class cmd_namep28(cmd_name):
    # cmd_name --> 'Lighting'
    def __init__(self, Lighting):
        pass

    def toCode(self):
        return 'Lighting'


class cmd_namep29(cmd_name):
    # cmd_name --> 'Cull'
    def __init__(self, Cull):
        pass

    def toCode(self):
        return 'Cull'


class cmd_namep30(cmd_name):
    # cmd_name --> 'ZTest'
    def __init__(self, ZTest):
        pass

    def toCode(self):
        return 'ZTest'


class cmd_namep31(cmd_name):
    # cmd_name --> 'ZWrite'
    def __init__(self, ZWrite):
        pass

    def toCode(self):
        return 'ZWrite'


class cmd_namep32(cmd_name):
    # cmd_name --> 'Blend'
    def __init__(self, Blend):
        pass

    def toCode(self):
        return 'Blend'


class idsp33(ids):
    # ids --> ID ids
    def __init__(self, ID, ids):
        self.ID = ID
        self.ids = ids

    def toCode(self):
        return self.ID.toCode() + self.ids.toCode()


class idsp34(ids):
    # ids -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class passesp35(passes):
    # passes --> shr_pass passes
    def __init__(self, shr_pass, passes):
        self.shr_pass = shr_pass
        self.passes = passes

    def toCode(self):
        return self.shr_pass.toCode() + self.passes.toCode()


class passesp36(passes):
    # passes -->
    def __init__(self):
        pass

    def toCode(self):
        return ''


class shr_passp37(shr_pass):
    # shr_pass --> 'Pass' { pass_body }
    def __init__(self, Pass, LBrace, pass_body, RBrace):
        self.pass_body = pass_body

    def toCode(self):
        return 'Pass' + '{' + self.pass_body.toCode() + '}'


class Test(unittest.TestCase):


    def test(self):
        pass
