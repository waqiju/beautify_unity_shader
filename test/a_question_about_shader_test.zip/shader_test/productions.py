from app.syntax_nonterminal import Nonterminal
from app.syntax_production import Production
from app.lex_tokens import TokenType as T
from .nonterminals import NonterminalType as N
import unittest


productionList = [
    Production("prog ->  'Shader' String { shader_body }",
               'p1',
               N.prog,
               ('Shader', T.String, T.LBrace, N.shader_body, T.RBrace, )),
    Production("shader_body ->  props subshr",
               'p2',
               N.shader_body,
               (N.props, N.subshr, )),
    Production("props ->  'Properties' { props_body }",
               'p3',
               N.props,
               ('Properties', T.LBrace, N.props_body, T.RBrace, )),
    Production("props -> ",
               'p4',
               N.props,
               ()),
    Production("props_body ->  prop_stm props_body",
               'p5',
               N.props_body,
               (N.prop_stm, N.props_body, )),
    Production("props_body -> ",
               'p6',
               N.props_body,
               ()),
    Production("prop_stm ->  ID ( String , prop_type ) = prop_init",
               'p7',
               N.prop_stm,
               (T.ID, T.LParen, T.String, T.Comma, N.prop_type, T.RParen, T.Assign, N.prop_init, )),
    Production("prop_type ->  'Color'",
               'p8',
               N.prop_type,
               ('Color', )),
    Production("prop_type ->  'Vector'",
               'p9',
               N.prop_type,
               ('Vector', )),
    Production("prop_type ->  'Range'",
               'p10',
               N.prop_type,
               ('Range', )),
    Production("prop_type ->  'Int'",
               'p11',
               N.prop_type,
               ('Int', )),
    Production("prop_type ->  'Float'",
               'p12',
               N.prop_type,
               ('Float', )),
    Production("prop_type ->  '2D'",
               'p13',
               N.prop_type,
               ('2D', )),
    Production("prop_type ->  'Cube'",
               'p14',
               N.prop_type,
               ('Cube', )),
    Production("prop_type ->  '3D'",
               'p15',
               N.prop_type,
               ('3D', )),
    Production("prop_init ->  Number",
               'p16',
               N.prop_init,
               (T.Number, )),
    Production("prop_init ->  String { }",
               'p17',
               N.prop_init,
               (T.String, T.LBrace, T.RBrace, )),
    Production("prop_init ->  ( Number , Number , Number , Number )",
               'p18',
               N.prop_init,
               (T.LParen, T.Number, T.Comma, T.Number, T.Comma, T.Number, T.Comma, T.Number, T.RParen, )),
    Production("subshr ->  'SubShader' { subshr_body }",
               'p19',
               N.subshr,
               ('SubShader', T.LBrace, N.subshr_body, T.RBrace, )),
    Production("subshr_body ->  tags cmds passes",
               'p20',
               N.subshr_body,
               (N.tags, N.cmds, N.passes, )),
    Production("tags ->  'Tags' { tags_body }",
               'p21',
               N.tags,
               ('Tags', T.LBrace, N.tags_body, T.RBrace, )),
    Production("tags_body ->  tag_smt tags_body",
               'p22',
               N.tags_body,
               (N.tag_smt, N.tags_body, )),
    Production("tags_body -> ",
               'p23',
               N.tags_body,
               ()),
    Production("tag_smt ->  String = String",
               'p24',
               N.tag_smt,
               (T.String, T.Assign, T.String, )),
    Production("cmds ->  cmd_stm cmds",
               'p25',
               N.cmds,
               (N.cmd_stm, N.cmds, )),
    Production("cmds -> ",
               'p26',
               N.cmds,
               ()),
    Production("cmd_stm ->  cmd_name ids",
               'p27',
               N.cmd_stm,
               (N.cmd_name, N.ids, )),
    Production("cmd_name ->  'Lighting'",
               'p28',
               N.cmd_name,
               ('Lighting', )),
    Production("cmd_name ->  'Cull'",
               'p29',
               N.cmd_name,
               ('Cull', )),
    Production("cmd_name ->  'ZTest'",
               'p30',
               N.cmd_name,
               ('ZTest', )),
    Production("cmd_name ->  'ZWrite'",
               'p31',
               N.cmd_name,
               ('ZWrite', )),
    Production("cmd_name ->  'Blend'",
               'p32',
               N.cmd_name,
               ('Blend', )),
    Production("ids ->  ID ids",
               'p33',
               N.ids,
               (T.ID, N.ids, )),
    Production("ids -> ",
               'p34',
               N.ids,
               ()),
    Production("passes ->  shr_pass passes",
               'p35',
               N.passes,
               (N.shr_pass, N.passes, )),
    Production("passes -> ",
               'p36',
               N.passes,
               ()),
    Production("shr_pass ->  'Pass' { pass_body }",
               'p37',
               N.shr_pass,
               ('Pass', T.LBrace, N.pass_body, T.RBrace, )),
]




















class Test(unittest.TestCase):

    def test(self):
        for production in productionList:
            print(production)


    def DtestTokenType(self):
        for ty in T:
            print(ty)


def _init():

    for p in productionList:
        # Production <--> Nonterminal
        name1 = p.left
        name2 = name1 + p.name

        cls1 = Nonterminal.getClass(name1)
        if cls1 is None:
            print('error: lack of nonterminal class. production = %s' % p)
        cls1.leadingProductions.append(p)
        cls2 = Nonterminal.getClass(name2) or Nonterminal.getClass(name1)
        cls2.production = p
        p.LeftNonterminalClass = cls2

        # add 'Shader' into TokenType
        stTuple = ()
        for elm in p.right:
            if elm not in T and elm not in N:
                newSt = '-%s-' % elm
                T.add(newSt)
                stTuple += (newSt,)
            else:
                stTuple += (elm,)
        p.right = stTuple


_init()
